import 'package:flutter/material.dart';

class AppTheme {
  static const String fontFamily = 'Satoshi-Regular';
  static const Color white = Colors.white;

  static double titleSize(bool isMobile) => isMobile ? 25 : 45;
  static double bodySize(bool isMobile) => isMobile ? 15 : 18;
  static double smallSize(bool isMobile) => isMobile ? 14 : 16;

  static EdgeInsets responsivePadding(BoxConstraints constraints) {
    final double width = constraints.maxWidth;
    final double horizontal = width > 1200
        ? 95
        : width > 992
        ? 64
        : width > 768
        ? 48
        : 24;
    final double vertical = width < 768 ? 24 : 40;
    return EdgeInsets.symmetric(horizontal: horizontal, vertical: vertical);
  }

  static EdgeInsets responsiveMargin(BoxConstraints constraints) {
    final double width = constraints.maxWidth;
    final double top = width < 768 ? 30 : 60;
    return EdgeInsets.only(top: top, bottom: 30);
  }
}

enum PageType {
  home,
  about,
  article,
  testimony,
}

class HeroSection extends StatelessWidget {
  final BoxConstraints constraints;
  final PageType? pageType;

  const HeroSection({
    super.key,
    required this.constraints,
    this.pageType,
  });

  bool get isMobile => constraints.maxWidth < 768;
  double get maxWidth =>
      constraints.maxWidth > 1200 ? 1200 : constraints.maxWidth * 0.95;



  @override
  Widget build(BuildContext context) {
    final titleData = _getTitleData();
    final descData = _getDescriptionData();

    return Padding(
      padding: AppTheme.responsivePadding(constraints),
      child: Container(
        width: maxWidth,
        margin: AppTheme.responsiveMargin(constraints),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Title
            RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: titleData['bold'],
                    style: TextStyle(
                      fontFamily: AppTheme.fontFamily,
                      fontSize: AppTheme.titleSize(isMobile),
                      fontWeight: FontWeight.w700,
                      color: AppTheme.white,
                      height: 1.2,
                    ),
                  ),
                  TextSpan(
                    text: titleData['normal'],
                    style: TextStyle(
                      fontFamily: AppTheme.fontFamily,
                      fontSize: AppTheme.titleSize(isMobile),
                      fontWeight: FontWeight.w400,
                      color: AppTheme.white,
                      height: 1.2,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),

            // Description
            Text.rich(
              TextSpan(
                children: [
                  TextSpan(
                    text: descData['normal1'],
                    style: TextStyle(
                      fontFamily: AppTheme.fontFamily,
                      fontSize: AppTheme.bodySize(isMobile),
                      color: AppTheme.white.withOpacity(0.9),
                      height: 1.6,
                    ),
                  ),
                  if (descData['bold'] != null)
                    TextSpan(
                      text: descData['bold'],
                      style: TextStyle(
                        fontFamily: AppTheme.fontFamily,
                        fontSize: AppTheme.smallSize(isMobile),
                        fontWeight: FontWeight.w600,
                        color: AppTheme.white,
                        height: 1.6,
                      ),
                    ),
                  if (descData['normal2'] != null)
                    TextSpan(
                      text: descData['normal2'],
                      style: TextStyle(
                        fontFamily: AppTheme.fontFamily,
                        fontSize: AppTheme.smallSize(isMobile),
                        color: AppTheme.white.withOpacity(0.9),
                        height: 1.6,
                      ),
                    ),
                ],
              ),
              textAlign: TextAlign.left,
            ),
          ],
        ),
      ),
    );
  }

  // ======================
  // DATA
  // ======================

  Map<String, String> _getTitleData() {
    switch (pageType) {
      case PageType.about:
        return {
          'bold': 'Mengenal JPS: ',
          'normal': 'Klaim mudah, perlindungan aman',
        };
      case PageType.article:
        return {
          'bold': 'Selamat datang ',
          'normal': 'di pusat informasi literasi JPS!',
        };
      case PageType.testimony:
        return {
          'bold': 'Bukti Nyata ',
          'normal': 'Pelayanan dan Kepercayaan',
        };
      case PageType.home:
      default:
        return {
          'bold': 'Kelola Polis dengan Mudah,\nCepat, dan Transparan',
        };
    }
  }

  Map<String, String> _getDescriptionData() {
    switch (pageType) {
      case PageType.about:
        return {
          'normal1':
          'Solusi lengkap pengelolaan polis aset Anda, hadir dengan informasi yang akurat, ringkas, dan selalu terpantau.',
        };
      case PageType.article:
        return {
          'normal1':
          'Temukan panduan praktis, istilah-istilah penting, tips memilih produk asuransi, hingga kisah nyata manfaat asuransi mikro di tengah masyarakat.',
        };
      case PageType.testimony:
        return {
          'normal1': 'JPS mendapatkan kepercayaan dari puluhan nasabah dan mitra melalui layanan yang ',
          'bold': 'jelas, praktis, dan solutif',
          'normal2': '. Berikut adalah pengalaman nyata dari mereka yang telah merasakan manfaatnya.',
        };
      case PageType.home:
      default:
        return {
          'normal1':
          'JPS adalah platform asuransi pintar yang memudahkan kamu mencari, memilih,\ndan klaim asuransi hanya dalam hitungan menit ',
          'bold': 'cepat, aman, dan terdaftar OJK',
          'normal2': '.',
        };
    }
  }
}