import 'package:flutter/material.dart';
import '../form_step_container.dart';

class IncidentDetailForm extends StatelessWidget {
  const IncidentDetailForm({super.key});

  @override
  Widget build(BuildContext context) {
    return FormStepContainer(
      children: [
        const _SectionTitle(icon: Icons.report_problem_outlined, title: 'Detail Kejadian/Kerugian'),
        const SizedBox(height: 16),
        Wrap(
          spacing: 20,
          runSpacing: 16,
          children: const [
            _InputField(label: 'Tanggal Kejadian (hh/bb/tttt)'),
            _InputField(label: 'Waktu (hh:mm)'),
            _InputField(label: 'Lokasi Kejadian'),
            _InputField(label: 'Estimasi Nilai Kerugian (Rp)'),
            _InputField(label: 'Deskripsi Kejadian', maxLines: 3, isFullWidth: true),
          ],
        ),
      ],
    );
  }
}

class _InputField extends StatelessWidget {
  final String label;
  final int maxLines;
  final bool isFullWidth;

  const _InputField({
    required this.label,
    this.maxLines = 1,
    this.isFullWidth = false,
  });

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width > 600;
    final width = isFullWidth || !isWide ? double.infinity : (MediaQuery.of(context).size.width - 120) / 2;

    return SizedBox(
      width: width,
      child: TextField(
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final IconData icon;
  final String title;

  const _SectionTitle({required this.icon, required this.title});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 20, color: Colors.black54),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
        ),
      ],
    );
  }
}
