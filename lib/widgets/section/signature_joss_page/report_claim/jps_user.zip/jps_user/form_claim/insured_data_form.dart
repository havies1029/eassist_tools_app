import 'package:flutter/material.dart';
import '../form_step_container.dart';

class InsuredDataForm extends StatelessWidget {
  const InsuredDataForm({super.key});

  @override
  Widget build(BuildContext context) {
    return FormStepContainer(
      children: [
        // Section 1 - Data Tertanggung
        const _SectionTitle(icon: Icons.person, title: 'Data Tertanggung'),
        const SizedBox(height: 16),
        Wrap(
          spacing: 20,
          runSpacing: 16,
          children: const [
            _InputField(label: 'Nama Lengkap'),
            _InputField(label: 'Nomor KTP'),
            _InputField(label: 'Email'),
            _InputField(label: 'No. Telp'),
            _InputField(label: 'Alamat Lengkap', maxLines: 3, isFullWidth: true),
          ],
        ),
        const SizedBox(height: 32),

        // Section 2 - Informasi Polis
        const _SectionTitle(icon: Icons.library_books, title: 'Informasi Polis'),
        const SizedBox(height: 16),
        Wrap(
          spacing: 20,
          runSpacing: 16,
          children: const [
            _InputField(label: 'Nomor Polis'),
            _DropdownField(label: '-- Pilih Jenis Asuransi --'),
            _InputField(label: 'Jenis Asuransi Lainnya (Jika Dipilih Lainnya)', isFullWidth: true),
          ],
        ),
      ],
    );
  }
}

class _InputField extends StatelessWidget {
  final String label;
  final int maxLines;
  final bool isFullWidth;

  const _InputField({
    required this.label,
    this.maxLines = 1,
    this.isFullWidth = false,
  });

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width > 600;
    final width = isFullWidth || !isWide ? double.infinity : (MediaQuery.of(context).size.width - 120) / 2;

    return IntrinsicHeight(
      child: SizedBox(
        width: width,
        child: TextField(
          maxLines: maxLines,
          decoration: InputDecoration(
            labelText: label,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            alignLabelWithHint: maxLines > 1,
          ),
        ),
      ),
    );
  }
}

class _DropdownField extends StatelessWidget {
  final String label;
  const _DropdownField({required this.label});

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width > 600;
    final width = isWide ? (MediaQuery.of(context).size.width - 120) / 2 : double.infinity;

    return IntrinsicHeight(
      child: SizedBox(
        width: width,
        child: DropdownButtonFormField<String>(
          items: const [
            DropdownMenuItem(value: '', child: Text('-- Pilih Jenis Asuransi --')),
            DropdownMenuItem(value: 'Jiwa', child: Text('Asuransi Jiwa')),
            DropdownMenuItem(value: 'Kesehatan', child: Text('Asuransi Kesehatan')),
            DropdownMenuItem(value: 'Lainnya', child: Text('Lainnya')),
          ],
          onChanged: (val) {},
          decoration: InputDecoration(
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          ),
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final IconData icon;
  final String title;

  const _SectionTitle({required this.icon, required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 16, top: 16),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Colors.black54),
          const SizedBox(width: 8),
          Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
          ),
        ],
      ),
    );
  }
}