// claim_stepper.dart (Revisi dengan step base lengkap dan file form modular)
import 'package:flutter/material.dart';
import 'form_claim/instruction_form.dart';
import 'form_claim/insured_data_form.dart';
import 'form_claim/incident_detail_form.dart';
import 'form_claim/claim_payment_form.dart';
import 'form_claim/supporting_documents_form.dart';

const _primaryColor = Color(0xFF79AB43);

class ClaimStepper extends StatefulWidget {
  const ClaimStepper({super.key});

  @override
  State<ClaimStepper> createState() => _ClaimStepperState();
}

class _ClaimStepperState extends State<ClaimStepper> {
  int currentStep = 0;

  final List<Widget> steps = const [
    InstructionForm(),
    InsuredDataForm(),
    IncidentDetailForm(),
    ClaimPaymentForm(),
    SupportingDocumentsForm(),
  ];

  final List<String> titles = [
    'Petunjuk',
    'Data Tertanggung',
    'Detail Kejadian',
    'Pembayaran Klaim',
    'Data Pendukung',
  ];

  final List<String> subtitles = [
    'Memahami Informasi',
    'Mengisi Data Pribadi',
    'Mengisi Data Kejadian',
    'Mengisi Data Bank',
    'Mengisi Data Pendukung',
  ];

  void next() {
    if (currentStep < steps.length - 1) {
      setState(() => currentStep++);
    }
  }

  void back() {
    if (currentStep > 0) {
      setState(() => currentStep--);
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final formWidth = constraints.maxWidth - 48; // padding horizontal (24 + 24)

        return Column(
          children: [
            const SizedBox(height: 16),
            _StepIndicator(
              currentStep: currentStep,
              titles: titles,
              subtitles: subtitles,
              totalWidth: formWidth,
            ),
            const SizedBox(height: 24),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: steps[currentStep],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (currentStep > 0)
                    OutlinedButton.icon(
                      onPressed: back,
                      icon: const Icon(Icons.arrow_back, color: Colors.orange),
                      label: const Text("Kembali", style: TextStyle(color: Colors.orange)),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Colors.orange),
                      ),
                    ),
                  if (currentStep < steps.length - 1)
                    ElevatedButton.icon(
                      onPressed: next,
                      icon: const Icon(Icons.arrow_forward),
                      label: const Text("Lanjut"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _primaryColor,
                      ),
                    ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

}

class _StepIndicator extends StatelessWidget {
  final int currentStep;
  final List<String> titles;
  final List<String> subtitles;
  final double totalWidth;

  const _StepIndicator({
    required this.currentStep,
    required this.titles,
    required this.subtitles,
    required this.totalWidth,
  });

  @override
  Widget build(BuildContext context) {
    final stepItemWidth = 100.0;
    final totalConnectors = titles.length - 1;
    final totalStepWidth = stepItemWidth * titles.length;
    final totalConnectorWidth = totalWidth - totalStepWidth;

    final connectorWidth = totalConnectors > 0
        ? (totalConnectorWidth / totalConnectors).clamp(8.0, 100.0)
        : 30.0;

    return Center(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: totalWidth),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(titles.length * 2 - 1, (index) {
            if (index.isEven) {
              final stepIndex = index ~/ 2;
              final isActive = stepIndex == currentStep;
              final isPassed = stepIndex < currentStep;
              return _StepItem(
                index: stepIndex,
                title: titles[stepIndex],
                subtitle: subtitles[stepIndex],
                isActive: isActive,
                isPassed: isPassed,
              );
            } else {
              final isPassed = ((index - 1) ~/ 2) < currentStep;
              return _StepConnector(
                isPassed: isPassed,
                width: connectorWidth,
              );
            }
          }),
        ),
      ),
    );
  }
}



class _StepItem extends StatelessWidget {
  final int index;
  final String title;
  final String subtitle;
  final bool isActive;
  final bool isPassed;

  const _StepItem({
    required this.index,
    required this.title,
    required this.subtitle,
    required this.isActive,
    required this.isPassed,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: isPassed || isActive ? _primaryColor : Colors.grey.shade300,
            border: Border.all(
              color: isPassed || isActive ? _primaryColor : Colors.grey.shade400,
              width: 2,
            ),
          ),
          child: Center(
            child: isPassed
                ? const Icon(
              Icons.check,
              color: Colors.white,
              size: 20,
            )
                : isActive
                ? Container(
              width: 8,
              height: 8,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
              ),
            )
                : Text(
              '${index + 1}',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.grey.shade600,
                fontSize: 16.97,
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          width: 100,
          child: Column(
            children: [
              Text(
                title,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 12.73,
                  color: isPassed || isActive ? _primaryColor : Colors.grey.shade600,
                ),
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: TextStyle(
                  fontSize: 10,
                  color: isPassed || isActive ? Colors.grey.shade700 : Colors.grey.shade500,
                ),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _StepConnector extends StatelessWidget {
  final bool isPassed;
  final double width;

  const _StepConnector({
    required this.isPassed,
    required this.width,
  });

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        width: width,
        height: 2,
        color: isPassed ? _primaryColor : Colors.grey.shade400,
      ),
    );
  }
}
