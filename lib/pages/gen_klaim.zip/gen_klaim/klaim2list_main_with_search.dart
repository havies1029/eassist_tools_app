import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:eassist_tools_app/blocs/gen_klaim/klaim2list_bloc.dart';
import 'klaim2list_list.dart';

class Klaim2ListMainPageWithSearch extends StatelessWidget {
  final String initialSearchText;
  const Klaim2ListMainPageWithSearch({super.key, required this.initialSearchText});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Progress Klaim • $initialSearchText")),
      backgroundColor: Colors.grey[100],
      body: _Klaim2ListBootstrapper(initialSearchText: initialSearchText),
    );
  }
}

/// Widget kecil untuk menembakkan RefreshKlaim2ListEvent sekali saat dibuka.
/// (Tidak menyentuh controller internal Klaim2ListPage)
class _Klaim2ListBootstrapper extends StatefulWidget {
  final String initialSearchText;
  const _Klaim2ListBootstrapper({required this.initialSearchText});

  @override
  State<_Klaim2ListBootstrapper> createState() => _Klaim2ListBootstrapperState();
}

class _Klaim2ListBootstrapperState extends State<_Klaim2ListBootstrapper> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<Klaim2ListBloc>().add(
        RefreshKlaim2ListEvent(searchText: widget.initialSearchText, hal: 0),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    // Pakai halaman existing kamu apa adanya.
    return const Klaim2ListPage();
  }
}
