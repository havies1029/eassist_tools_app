import 'package:flutter/material.dart';
import 'package:eassist_tools_app/widgets/mobiledesign_widget.dart';
import 'package:eassist_tools_app/pages/gen_klaim/klaim1crud_form.dart';

class Klaim1CrudMainPage extends StatelessWidget {
	final String viewMode;
	final String recordId;
	const Klaim1CrudMainPage({super.key, required this.viewMode, required this.recordId});

	@override
	Widget build(BuildContext context) {
		return MobileDesignWidget(
			child: Scaffold(
				appBar: AppBar(
					title: Text('${viewMode == "tambah"?"Tambah":"Ubah"} Klaim 1'),
				),
				body: Klaim1CrudFormPage(viewMode: viewMode, recordId: recordId)));
	}
}
